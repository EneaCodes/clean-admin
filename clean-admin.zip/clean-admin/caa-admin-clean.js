(function () {
    function text(el) {
        return (el.innerText || el.textContent || "").toLowerCase();
    }

    function runClean() {
        var opts = window.CAA_OPTIONS || {};

        var promoWords = Array.isArray(opts.promoWords) ? opts.promoWords : [];
        var reviewWords = Array.isArray(opts.reviewWords) ? opts.reviewWords : [];

        promoWords = promoWords.map(function (w) {
            return String(w).toLowerCase();
        });

        reviewWords = reviewWords.map(function (w) {
            return String(w).toLowerCase();
        });

        var notices = document.querySelectorAll(
            ".notice, .updated, .update-nag, .welcome-panel, .elementor-message, .e-notice, .error, .notice-warning, .notice-error"
        );

        notices.forEach(function (el) {
            var t = text(el);
            if (!t) return;

            // Keep security / error-ish things visible.
            if (
                t.indexOf("security") !== -1 ||
                t.indexOf("malware") !== -1 ||
                t.indexOf("hacked") !== -1 ||
                t.indexOf("vulnerability") !== -1 ||
                t.indexOf("vulnerabilities") !== -1 ||
                t.indexOf("attack") !== -1 ||
                t.indexOf("critical error") !== -1 ||
                t.indexOf("failed") !== -1
            ) {
                return;
            }

            var cls = el.className || "";
            var isCoreUpdate =
                cls.indexOf("update-core") !== -1 ||
                t.indexOf("wordpress %s is available".toLowerCase()) !== -1;

            if (isCoreUpdate) {
                return;
            }

            var shouldHide = false;

            if (opts.hide_dashboard_ads && (el.closest("#dashboard-widgets-wrap") || el.closest(".welcome-panel"))) {
                shouldHide = true;
            }

            if (!shouldHide && opts.hide_plugin_promos) {
                for (var i = 0; i < promoWords.length; i++) {
                    if (t.indexOf(promoWords[i]) !== -1) {
                        shouldHide = true;
                        break;
                    }
                }
            }

            if (!shouldHide && opts.hide_review_nags) {
                for (var j = 0; j < reviewWords.length; j++) {
                    if (t.indexOf(reviewWords[j]) !== -1) {
                        shouldHide = true;
                        break;
                    }
                }
            }

            if (shouldHide) {
                el.style.display = "none";
            }
        });
    }

    document.addEventListener("DOMContentLoaded", function () {
        runClean();
        setTimeout(runClean, 1500);
        setTimeout(runClean, 4000);
    });
})();
